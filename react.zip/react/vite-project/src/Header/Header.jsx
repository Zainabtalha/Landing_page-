const Header = ()=>{
    <>
   <nav className="navbar">
      <ul className="navbar-nav">
        <li className="nav-item">
          <Link to="/" className="nav-link">Home</Link>
        </li>
        <li className="nav-item">
          <Link to="/pages" className="nav-link">Pages</Link>
        </li>
        <li className="nav-item">
          <Link to="/courses" className="nav-link">Courses</Link>
        </li>
       
        <li className="nav-item">
          <Link to="/blog" className="nav-link">Blog</Link>
        </li>

        <li className="nav-item">
          <Link to="/contact" className="nav-link">Contact</Link>
        </li>
      </ul>
    </nav>
    </>
}
export default Header;