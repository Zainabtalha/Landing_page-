import react from 'react'
import Header from './Header/Header'

const App = ()=>{
  <>
  <Header/>
  </>
}

export default App
